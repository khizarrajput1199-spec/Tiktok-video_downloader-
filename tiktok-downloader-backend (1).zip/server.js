require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

const THIRD_API_URL = process.env.THIRD_API_URL || null;
const THIRD_API_KEY = process.env.THIRD_API_KEY || null;

// Health check
app.get('/', (req, res) => res.send('TikTok downloader backend ✅'));

// POST /api/download
app.post('/api/download', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'TikTok URL required in body as { url }' });
    }

    let videoUrl = null;
    if (THIRD_API_URL && THIRD_API_KEY) {
      try {
        const resp = await axios.post(THIRD_API_URL, { url }, {
          headers: {
            'Authorization': `Bearer ${THIRD_API_KEY}`,
            'Content-Type': 'application/json'
          },
          timeout: 20000
        });
        if (resp.data && (resp.data.videoUrl || resp.data.url)) {
          videoUrl = resp.data.videoUrl || resp.data.url;
        }
      } catch (err) {
        console.warn('Third-party extractor failed:', err.message || err);
      }
    }

    if (!videoUrl) {
      try {
        videoUrl = await extractUsingPuppeteer(url);
      } catch (err) {
        console.warn('Puppeteer extractor failed:', err.message || err);
      }
    }

    if (!videoUrl) {
      return res.status(500).json({ error: 'Could not extract a direct video URL. Configure third-party API or enable puppeteer.' });
    }

    const upstream = await axios.get(videoUrl, { responseType: 'stream', timeout: 30000 });
    const contentType = upstream.headers['content-type'] || 'application/octet-stream';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'attachment; filename="tiktok_video.mp4"');

    upstream.data.pipe(res);
    upstream.data.on('error', (err) => {
      console.error('Upstream stream error:', err);
      try { res.end(); } catch(e){}
    });

  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Server error', detail: err.message });
  }
});

async function extractUsingPuppeteer(url) {
  let puppeteer;
  try {
    puppeteer = require('puppeteer');
  } catch (e) {
    throw new Error('puppeteer is not installed. Run `npm install puppeteer` to enable this extractor.');
  }

  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
    headless: true
  });

  try {
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36');
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
    await page.waitForTimeout(1000);

    const videoSrc = await page.evaluate(() => {
      const v = document.querySelector('video');
      if (v && v.src) return v.src;
      const og = document.querySelector('meta[property="og:video"]') || document.querySelector('meta[name="og:video"]');
      if (og && og.content) return og.content;
      const scripts = Array.from(document.querySelectorAll('script')).map(s => s.textContent).join('\n');
      const m = scripts.match(/"playAddr":"(https:[^"]+)"/);
      if (m && m[1]) {
        return m[1].replace(/\\/g, '');
      }
      return null;
    });

    await page.close();
    await browser.close();
    return videoSrc;
  } catch (err) {
    try { await browser.close(); } catch(e){}
    throw err;
  }
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
